package com.naufalhilal.listticketbusdenganrecycleview;

public class Tiket {
    private String kota_asal;
    private String jam_brkt;
    private String tgl_brkt;
    private String harga;
    private String kota_tujuan;
    private String jam_sampai;
    private String tgl_sampai;

    public String getKota_asal() {
        return kota_asal;
    }

    public void setKota_asal(String kota_asal) {
        this.kota_asal = kota_asal;
    }

    public String getJam_brkt() {
        return jam_brkt;
    }

    public void setJam_brkt(String jam_brkt) {
        this.jam_brkt = jam_brkt;
    }

    public String getTgl_brkt() {
        return tgl_brkt;
    }

    public void setTgl_brkt(String tgl_brkt) {
        this.tgl_brkt = tgl_brkt;
    }

    public String getHarga() {
        return harga;
    }

    public void setHarga(String harga) {
        this.harga = harga;
    }

    public String getKota_tujuan() {
        return kota_tujuan;
    }

    public void setKota_tujuan(String kota_tujuan) {
        this.kota_tujuan = kota_tujuan;
    }

    public String getJam_sampai() {
        return jam_sampai;
    }

    public void setJam_sampai(String jam_sampai) {
        this.jam_sampai = jam_sampai;
    }

    public String getTgl_sampai() {
        return tgl_sampai;
    }

    public void setTgl_sampai(String tgl_sampai) {
        this.tgl_sampai = tgl_sampai;
    }
}
