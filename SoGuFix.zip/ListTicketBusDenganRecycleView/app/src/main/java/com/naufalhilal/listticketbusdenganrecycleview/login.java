package com.naufalhilal.listticketbusdenganrecycleview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class login extends AppCompatActivity {

    private EditText userEdt, pasEdt;
    private Button buttonLgn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
//        getSupportActionBar().hide();
        initView();
        setVariable();
    }
    private void setVariable(){
        buttonLgn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                if(userEdt.getText().toString().isEmpty() || pasEdt.getText().toString().isEmpty()){
                    Toast.makeText(login.this, "Please fill the form", Toast.LENGTH_SHORT).show();
                }else{
                    startActivity(new Intent(login.this, searchTiket.class));
                    finish();
                }
            }
        });

    }
    private void initView(){
        userEdt = findViewById(R.id.editTextTextPersonName);
        pasEdt = findViewById(R.id.editTextTextPassword);
        buttonLgn = findViewById(R.id.buttonlg);
    }
}