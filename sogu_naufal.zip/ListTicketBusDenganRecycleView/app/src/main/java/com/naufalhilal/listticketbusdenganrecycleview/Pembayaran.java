package com.naufalhilal.listticketbusdenganrecycleview;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import java.util.Random;

public class Pembayaran extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pembayaran);
        TextView kode=findViewById(R.id.kode_pambayaran);
        Random random=new Random();
        int n=random.nextInt(1000000000);
        kode.setText(Integer.toString(n));
    }

    public void gotoMainActivity(View view){
        Intent intent=new Intent(this,MainActivity.class);
        startActivity(intent);
        finish();
    }
}