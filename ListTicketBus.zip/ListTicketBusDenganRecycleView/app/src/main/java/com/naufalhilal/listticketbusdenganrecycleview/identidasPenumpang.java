package com.naufalhilal.listticketbusdenganrecycleview;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.fragment.app.FragmentTransaction;

import android.os.Bundle;
import android.view.MenuItem;

import com.google.android.material.bottomnavigation.BottomNavigationView;

public class identidasPenumpang extends AppCompatActivity implements BottomNavigationView.OnNavigationItemSelectedListener {
    Fragment fragment;
    FragmentManager fragmentManager;
    FragmentTransaction fragmentTransaction;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_identidas_penumpang);
        loadFragment(new homefragmen_ip());
        BottomNavigationView bottomNavigationView=findViewById(R.id.fragment_container);
        bottomNavigationView.setItemIconTintList(null);
        bottomNavigationView.setOnNavigationItemSelectedListener(this);
    }

    private boolean loadFragment(homefragmen_ip Fragment) {
        if (Fragment!=null){
            getSupportFragmentManager().beginTransaction().replace(R.id.container_layout,Fragment).commit();
            return true;
        }
        return false;
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        homefragmen_ip fragment=null;
        switch (item.getItemId()){
            case R.id.nav_home:
                fragment=new homefragmen_ip();
                break;
            case R.id.profil:
                fragment=new homefragmen_ip();
                break;
        }
        return loadFragment(fragment);
    }
}